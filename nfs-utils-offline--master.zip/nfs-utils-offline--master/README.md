# nfs-utils-offline-


**** WARNING: WILL NEED TO EXECUTE TWICES THE NFS.SH AND EVERY RPM FILES WILL NEED BE IN SAME FOLDER THAT SH SCRIPT FILE TO WORK CORRECTLY****

Install nfs-utils on centos 7 without internet connection

